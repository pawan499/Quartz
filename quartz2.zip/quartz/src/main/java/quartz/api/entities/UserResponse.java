package quartz.api.entities;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UserResponse {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long resonseId;
	private String refName;
	private long refId;
	public UserResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserResponse(long resonseId, long refId, String refName) {
		super();
		this.resonseId = resonseId;
		this.refId = refId;
		this.refName = refName;
	}

	public long getResonseId() {
		return resonseId;
	}
	public void setResonseId(long resonseId) {
		this.resonseId = resonseId;
	}
	public long getRefId() {
		return refId;
	}
	public void setRefId(long refId) {
		this.refId = refId;
	}
	public String getRefName() {
		return refName;
	}
	public void setRefName(String refName) {
		this.refName = refName;
	}
	
}
