package quartz.api.services;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import quartz.api.entities.User;
import quartz.api.repositories.UserRepository;
@Service
public class UserService {
	@Autowired
	private UserRepository repo;

	public User saveUser(User u) {
		User k=null;
		try {
		if(repo.findById(u.getRes().getRefId()).isEmpty()) {
			k= null;
		}else
		 k=repo.save(u);
		}catch(Exception e) {
			k= null;
		}
		return k;
	}

	public List<User> findAllUser(User u){
		List<User> users=null;
		if(repo.findByNameAndPassword(u.getName(),u.getPassword()).isEmpty()) {
			users= null;
		}else {
			try {
			 users=(List<User>)repo.findAll();
			
			}catch(Exception e) {
				users= null;
			}
			
		}
		return users;
		
	}
	public Optional<User> getUser(long refId) {
		Optional<User> u=null;
		try {
		  u= repo.findById(refId);
		}
		catch(Exception e) {
			u=null;
		}
		return u;
	}
	
}
