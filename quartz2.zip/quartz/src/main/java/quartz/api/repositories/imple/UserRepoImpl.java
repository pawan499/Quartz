package quartz.api.repositories.imple;

public class UserRepoImpl {

}
