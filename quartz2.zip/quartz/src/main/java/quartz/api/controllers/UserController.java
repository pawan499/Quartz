package quartz.api.controllers;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import quartz.api.entities.User;
import quartz.api.entities.UserResponse;
import quartz.api.services.UserService;

@RestController
@CrossOrigin
public class UserController {
	private static String generatePassword() {
		Random r=new Random();
		String s="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz123456789";
		String pass="";
		for(int i=1;i<=8;i++) {
			pass=pass+s.charAt(r.nextInt(0, s.length()-1));
		}
		return pass; 
	}
	@Autowired
	private  UserService  serv;
	@PostMapping("/add")
	public User addUser(@RequestBody User u) {
		User t=null;
		try {
			Optional<User> k=serv.getUser(u.getRes().getRefId());
			UserResponse response=new UserResponse();
			response.setRefName(k.get().getName());
			response.setRefId(u.getRes().getRefId());
			u.setPassword(generatePassword());
			u.setRes(response);
			u.setDate(new Date());
			t=serv.saveUser(u);
	      }catch(Exception e) {
	    	  t=null;
	      }
		
		return t;
	}
	
	@PostMapping("/login")
	public List<User> getAllUser(@RequestBody User u){
		List<User> users= serv.findAllUser(u);
		return users;
	}
	
	
}
